class SubscriptionAPI {

}